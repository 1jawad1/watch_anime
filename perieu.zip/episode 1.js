function list1() {
  document.getElementById('l').classList.toggle("la");
}
