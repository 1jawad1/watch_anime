
function list(){
  document.getElementById('list-num-2').classList.toggle("la");
document.getElementById('list-num-21').classList.toggle("la");

}

function list1(){
  document.getElementById('m').classList.toggle("lal");
}
