function list(){
  document.getElementById('m').classList.toggle("la");
document.getElementById('selec').classList.toggle("la");
document.getElementById('mmm').style.display = 'none';
document.getElementById('mmm').classList.toggle("ma");
}


function rech(){

var a = document.getElementById('selec').value;


if (a === 'shingeki no kiojin') {

     window.open('jawad.htm');

}


}


function img() {
  document.getElementById('mmm').style.display='block'
}

function bobo() {
  document.getElementById('mmm').style.display='none'
}
